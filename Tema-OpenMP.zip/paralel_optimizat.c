#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<stdbool.h>
//Functie de calculare a minimului
int min(int a, int b){
	if (a <= b)
		return a;
	
		return b;
	
}
//Functie de calculare a maximului
int max(int a, int b){
	if (a >= b)
		return a;
	
		return b;
	
}
//Functie care calculeaza modulul unui numar
int modul(int a){
	if (a < 0)
		return -a;
	return a;
}

//Functie care calculeaza maximul dintr-un vector
int maximum(int vector[], int dim, int delete[]){
int maxim = -1;
int i, j;
	for(i = 0; i < dim; i++)
		if(vector[i] > maxim){
			if(delete[i] < 0)
				maxim = vector[i]; 
			}
	return maxim;

}

//Functie care returneaza pozitia primului maxim dintr-un vector
int maxim(int vector[], int dim){
int maxim = -1;
int i, ind;
	for(i = dim-1; i >= 0; i--)
		if(vector[i] >= maxim && vector[i] <10000){
			maxim = vector[i];
			ind = i;
			}
	return ind;

}


int main(int argc, char* argv[]){

 	
	int el, N = 0, Nc = 0, i = 0, j = 0, k, l, m, n, o, r, s, t, p, z, indice, nr;
	int v[4]; v[0] = 5; v[1] = 2; v[2] = 3; v[3] = 9; 
	int week;
	
  FILE *fi, *fo;
  
	fi = fopen(argv[2],"r"); 
	fo = fopen(argv[3],"w");
 	int weeks = atoi(argv[1]);
 	fscanf(fi, "%i", &N);
 	printf("dim_matrice %i", N);
 	fscanf(fi, "%i", &Nc);
 	printf("nr_partide %i \n", Nc);
 	int matrix[N][N];
 	int matrix1[N][N];
 	int parties[Nc];
 	int parties_numarare[Nc], parties_numarare1[Nc];
 	int delete[Nc];
 	int chuck = N;
 	
 	//Citire matrice din fisier
  for(i = 0; i < N; i++)
   		for (j = 0; j < N; j++){
 					fscanf(fi, "%i", &el);
 					matrix[i][j] = el;		  		
   		}
				 
   fclose(fi);
   //Initializarea vectorului de partide care au disparut
   for(o = 0; o < Nc; o++)
   		delete[o] = -500;
   
   
   		//Parcurgerea saptamanilor
	for (week = 0; week < weeks; week++){
	
   //Initializarea vectorului in care este memorat numarul de membri ai fiecarui partid
   for(o = 0; o < Nc; o++){
   		parties_numarare[o] = 0;
  	}
   
   	//Parcurgerea matricii
   	#pragma omp parallel for private(k, l, parties, i, j, indice) shared(chuck, matrix) schedule(static, chuck)
   	for(k = 0; k < N; k++)//linii
   		for(l = 0; l < N; l++){//coloane
   			
   
   	//Initializare vectorului ce contine minimele distantelor
   		for(o = 0; o < Nc; o++)
   			parties[o] = 10000;
   			
   		if (parties_numarare1[matrix[k][l]] == 1) 
   			parties[matrix[k][l]] = 0;	
   			
   		nr = 1;
   		//Ciclare cat timp maximul din vectorul de distante minime este 10000
   		while(maximum(parties, Nc, delete) == 10000){
		
				if(k-nr <= 0) r = 0; else r = k - nr;
				if(k+nr > N-1)	p = N-1; else p = k + nr;
			
				if(l-nr <= 0) s = 0; else s = l - nr;
				if(l+nr > N-1)	t = N-1; else t = l + nr;
   		
   		
   			i = r+1;
   			j = s;
   			//Parcurgerea coloanelor de pe conturul zonei concentrice
   			while(i <= p-1){
   		
   				if (i == k && s == l)
   					parties[matrix[i][s]] = parties[matrix[i][s]];
   				else {
   						parties[matrix[i][s]] = min(parties[matrix[i][s]], nr);
   					}
   			
   			if (i == k && t == l)
   				parties[matrix[i][t]] = parties[matrix[i][t]];
   			else {
   					parties[matrix[i][t]] = min(parties[matrix[i][t]], nr);
   			}
   			i++;
   		}
   		//Parcurgerea liniilor de pe conturul zonei concentrice	       
   			while(j <= t){
   			
   				if (r == k && j == l)
   					parties[matrix[r][j]] = parties[matrix[r][j]];
   				else {	
   						parties[matrix[r][j]] = min(parties[matrix[r][j]], nr);   				
   						}
   			
   				if (p == k && j == l)
   					parties[matrix[p][j]] = parties[matrix[p][j]];
   				else {
   						parties[matrix[p][j]] = min(parties[matrix[p][j]], nr);
   				}
   				j++;		
   		 }
   		
   		nr++;
   		}
   		//Memorarea valorilor minime in vector
   		indice = maxim(parties, Nc);
   		matrix1[k][l] = indice;
   		//Construirea vectorului cu numarul de membri ai fiecarui partid 
   		#pragma omp critical 
   		parties_numarare[indice]++;	
   		
   	}
   		//Realizarea unei copii pentru matricea construita
   		for(m = 0; m < N; m++)
   			for (n = 0; n < N; n++)
   				matrix[m][n] = matrix1[m][n];
   				
   		//Scrierea in fisier a fiecarui vector ce contine numarul de senatori din fiecare partid
   		for(m = 0; m < Nc; m++){
   			parties_numarare1[m] = parties_numarare[m];
   			fprintf(fo, "%i ", parties_numarare[m]);
   			
   		//Construirea vectorului de partide eliminate	
   			if (parties_numarare[m] == 0){
   				delete[m] = m;
   			}
   			
   		}
   			fprintf(fo, "\n");
   			
   		}
  //Scrierea in fisier a matricii finale
   for(i = 0; i < N; i++){
   	for (j = 0; j < N; j++)
   		fprintf(fo, " %d ", matrix[i][j]);
   	fprintf(fo, "\n");
   }
   	fclose(fo);	
   		
   return 0;
}
