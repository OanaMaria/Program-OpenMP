#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<omp.h>

//Functie de calculare a minimului
int min(int a, int b){
	if (a <= b)
		return a;
	
		return b;
}

//Functie de calculare a maximului
int max(int a, int b){
	if (a >= b)
		return a;
	
		return b;
	
}
//Functie care calculeaza modulul unui numar
int modul(int a){
	if (a < 0)
		return -a;
	return a;
}

//Functie care returneaza pozitia primului maxim dintr-un vector
int maxim(int vector[], int dim){
int maxim = -1;
int i, ind;
	for(i = dim-1; i >= 0; i--)
		if(vector[i] >= maxim && vector[i] < 10000){
			maxim = vector[i];
			ind = i;
			}
	return ind;
}

int main(int argc, char* argv[]){

 	
	int el, N = 0, Nc = 0, i = 0, j = 0, k, l, m, n, o, indice;
	int week;
  FILE *fi, *fo;
  fi = fopen(argv[2],"r"); 
 	fo = fopen(argv[3],"w"); 
 	int weeks = atoi(argv[1]);
 	fscanf(fi, "%i", &N);
 	fscanf(fi, "%i", &Nc);
 	 int matrix[N][N];
 	 int matrix1[N][N];
 	 int parties[Nc];
 	 int parties_numarare[Nc];
 	 int chuck = N;
 	 //Citirea matricii din fisier
  for(i = 0; i < N; i++)
   		for (j = 0; j < N; j++){
 					fscanf(fi, "%i", &el);
 					matrix[i][j] = el;		  		
   		}
				 
   fclose(fi);
   //Parcurgerea saptamanilor
   for (week = 0; week < weeks; week++){
   
   //Initializarea vectorului in care este memorat numarul de membri ai fiecarui partid
   	for(o = 0; o < Nc; o++)
   		parties_numarare[o] = 0;
   
   //Parcurgerea matricii	
   #pragma omp parallel for private(k, l, parties, i, j, indice) shared(chuck, matrix) schedule(static, chuck)	
   for(k = 0; k < N; k++)//linii
   	for(l = 0; l < N; l++){//coloane
   	
   	//Initializare vectorului ce contine minimele distantelor
   	for(o = 0; o < Nc; o++)
   		parties[o] = 10000;
   		
   		//Parcurgerea matricii
   		for(j = 0; j < N; j++)//coloane
   			for (i = 0; i < N; i++){//linii
   			
   						//Construirea vectorului de distante minime
   						if (i == k && j == l)
   							parties[matrix[i][j]] = parties[matrix[i][j]];
   						else 
   							parties[matrix[i][j]] = min(parties[matrix[i][j]], max(modul(i - k), modul(j - l)));
   					
   		}
   		indice = maxim(parties, Nc);
   		matrix1[k][l] = indice; 
   		
   		//Construirea matricii cu numarul de membrii ai fiecarui partid
   		#pragma omp critical 
   		parties_numarare[indice]++;
   		
   		}
   		//Realizarea unei copii pentru matricea construita
   		for(m = 0; m < N; m++)
   			for (n = 0; n < N; n++)
   				matrix[m][n] = matrix1[m][n];
   		
   		//Scrierea in fisier a fiecarui vector ce contine numarul de senatori din fiecare partid		
   		for(m = 0; m < Nc; m++)
   			fprintf(fo, "%i  ", parties_numarare[m]);
   			fprintf(fo, "\n");
   		}
   		
   for(i = 0; i < N; i++){
   	for (j = 0; j < N; j++)
   		fprintf(fo, " %d ", matrix[i][j]);
   	fprintf(fo, "\n");
   }
   			
   return 0;
}
